const listadoUrls = [
    'https://lk.cl/#!/Producto=14065',
    'https://lk.cl/#!/Producto=13913',
  ];

  module.exports = { listadoUrls };